class Node(object):
    """
    This node class contains information about a given enumeration that the user inputs. These nodes are a part of a directed graph.
    """
    def __init__(self, val):
        self.val = val
        self.edges = []

    def add_edge(self, val, node):
        for edge in self.edges:
            if val == edge.val:
                edge.weight += 1
                return
        self.edges.append(Edge(val, node))

    def total_weight(self):
        return sum(edge.weight for edge in self.edges)


class Edge(object):
    """
    The edge class allows the connection of two nodes and also gives information about which patterns are more frequent. An edge with higher weight means that the pattern is more present in the given text/url/string.
    """
    def __init__(self, val, node):
        self.destination = node
        self.val = val
        self.weight = 1
