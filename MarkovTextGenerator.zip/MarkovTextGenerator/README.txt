Group Members: Chanakya Remani and Aditya Gadiyar

Objective:

The objective of this application was to create a Markov chain that models the
probabilities associated with language patterns for the purpose of text-generation
by a computer. Edge and node classes were created to form a weighted, directed
graph; nodes correspond to tokens (words, characters, etc.), while edge-weight
corresponds to the probability that a certain token follows the current token.
The Markov chain was used to simulate text generation based on input from both
text files and URLs. The sophistication of the Markov chain can be manually
selected on a scale of 1-10 for varying degrees of accuracy in text prediction.

To Run:

Execute 'python3 markovtextgenerator.py' from the command line

The parameters of the Markov chain are selected in markovtextgenerator.py.
markovchain.TextGenerator() creates the Markov chain object and takes in 2
parameters: the level of sophistication and the method of tokenization.
The data source can also be selected in this file. Similarly, this can be opened in 
Visual Studio and sample test cases can be run by commenting out the other ones.

*NOTE: For URLs, the urllib.request library is used. On MacOS and Windows,
this may require certain certificates to be downloaded. However, the URL
functionality has been successfully tested on the Linux lab machines in the GDC.
