import markovchain
import itertools

text_generator = markovchain.TextGenerator(2, markovchain.Token.word)

#data = "Chapter 1-3.txt"
#text_generator.train_text_file(data)

data = "http://www.singingwizard.org/stuff/pg24132.txt"
text_generator.train_url(data)

#text_generator.train_iterable("What a piece of work is man! how noble in reason! how infinite in faculty! in form and moving how express and admirable! "
#"in action how like an angel! in apprehension how like a god! the beauty of the world, the paragon of animals!")

# the second parameter (the number) can be changed
for i in itertools.islice(text_generator.generate(), 300):
    print(str(i) + " ", end="")
